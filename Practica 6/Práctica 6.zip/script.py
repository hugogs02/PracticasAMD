import pandas as pd
import numpy as np
import seaborn as sns
from matplotlib import pyplot as plt
from statsmodels import api as sm
sns.set()

#-----------------------------------------------------
#------------Creación de series temporales------------

#---------------------Variable TM---------------------
print("----------Variable TM------------")
# importar CSV
serieTM = pd.read_csv('./TM_Santiago_limpio.csv')

# ver dataframe
print(serieTM.head(4))
print(serieTM.tail(4))

# resumen dataframe
print(serieTM.shape)
print(serieTM.describe())

# AFC normal
TM = serieTM.loc[:,"TM"]
sm.graphics.tsa.plot_acf(TM, title="TM - Autocorrelación")

# AFC de la primera diferencia
TM_diff_1 = np.diff(TM)
sm.graphics.tsa.plot_acf(TM_diff_1, title="Primera Diferencia TM - Autocorrelación")

# AFC de la segunda diferencia
TM_diff_2 = np.diff(TM_diff_1)
sm.graphics.tsa.plot_acf(TM_diff_2, title="Segunda Diferencia TM - Autocorrelación")

plt.show()

# importar CSV
serieTM = pd.read_csv('./TM_Santiago_limpio.csv', parse_dates = True)

# campo Fecha como índice
serieTM['Fecha'] = pd.to_datetime(serieTM['Fecha'])
serieTM = serieTM.set_index('Fecha')

# ver dataframe
print(serieTM.head(4))
print(serieTM.tail(4))

# resumen dataframe
print(serieTM.shape)
print(serieTM.describe())

# descomponer en componentes estacionales, tendencia y residuos
descomposicion_TM = sm.tsa.seasonal_decompose(serieTM.TM, model='additive', period=6003)
descomposicion_TM.plot()

plt.show()

descomposicion_TM = sm.tsa.seasonal_decompose(serieTM.TM, model='additive', period=375)
descomposicion_TM.plot()

plt.show()


#---------------------Variable P---------------------
print("----------Variable P------------")
#empezamos leyendo el .csv
sns.set()
serieP = pd.read_csv('P_Santiago.csv')

#ver dataframe y resumen del dataframe
print(serieP.head(4))
print(serieP.tail(4))
print(serieP.shape)
print(serieP.describe())

P = serieP.loc[:,"P"]
sm.graphics.tsa.plot_acf(P,title="P - Autocorrelacion")
plt.show()

P_diff_1 = np.diff(P)
sm.graphics.tsa.plot_acf(P_diff_1,title="Primera diferencia P - Autocorrelacion")
plt.show()

P_diff_2 = np.diff(P_diff_1)
sm.graphics.tsa.plot_acf(P_diff_2,title="Segunda diferencia P - Autocorrelacion")
plt.show()


serieP = pd.read_csv('P_Santiago_limpio.csv', parse_dates = True)
print(serieP.head(4))
print(serieP.tail(4))
print(serieP.shape)
print(serieP.describe())
serieP['Fecha'] = pd.to_datetime(serieP['Fecha'])
serieP = serieP.set_index('Fecha')

P = serieP.loc[:,"P"]

descomposicion_P = sm.tsa.seasonal_decompose(serieP.P, model= 'additive', period=2965)
descomposicion_P.plot()
plt.show()

descomposicion_P = sm.tsa.seasonal_decompose(serieP.P,model= 'additive',period=371)
descomposicion_P.plot()
plt.show()


#---------------------Variable IRRA---------------------
print("----------Variable IRRA------------")
#Importamos el csv
serieIRRA=pd.read_csv('IRRA_Santiago_limpio.csv')

#Vemos el dataframe y un resumen
print(serieIRRA.head(4))
print(serieIRRA.tail(4))
print(serieIRRA.shape)
print(serieIRRA.describe())

#Obtenemos la AFC de la serie, la primera y la segunda diferencia
IR=serieIRRA.loc[:,"Irradiacion_global_diaria"]
sm.graphics.tsa.plot_acf(IR,title='Autocorrelación IR')

IR_diff_1=np.diff(IR)
sm.graphics.tsa.plot_acf(IR_diff_1,title='Autocorrelación IR (primera diferencia)')

IR_diff_2=np.diff(IR_diff_1)
sm.graphics.tsa.plot_acf(IR_diff_2,title='Autocorrelación IR (segunda diferencia)')

plt.show()


#Volvemos a importar el csv parseando las fechas y estableciendo el índice
serieIRRA=pd.read_csv('IRRA_Santiago_limpio.csv',index_col=0,parse_dates=['Fecha'])

#Descomponemos la serie
descIRRA=sm.tsa.seasonal_decompose(serieIRRA.IR,model='additive', period=2981)
descIRRA.plot()

descIRRA=sm.tsa.seasonal_decompose(serieIRRA.IR,model='additive', period=372)
descIRRA.plot()

plt.show()



#-----------------------------------------------------
#------------Creación de series temporales------------

#---------------------Variable TM---------------------
print("----------Variable TM------------")
# interpolacion lineal de la tendencia
np_Tendencia = np.array(descomposicion_TM.trend)
finite_indexes = np.isfinite(np_Tendencia)
coeficientes = np.polyfit(np.array(pd.to_datetime(descomposicion_TM.trend.index).astype(int) / 10**18)[finite_indexes],np_Tendencia[finite_indexes],1)
funcion_regresion = np.poly1d(coeficientes)

# insercion de columnas tendencia y regresion en el dataframe
serieTM.insert(1, 'Tendencia', descomposicion_TM.trend.interpolate(method="linear"))
serieTM.insert(2, 'Regresion', funcion_regresion(np.array(pd.to_datetime(serieTM.index).astype(int) / 10**18)))

# gráfica: interpolacion lineal con regresion lineal
plt.plot(serieTM.index, serieTM.Tendencia, serieTM.Regresion)

# pendiente de la regresion lineal
print(coeficientes)

plt.show()


#---------------------Variable P---------------------
print("----------Variable P------------")
tend = descomposicion_P.trend
inter=tend.interpolate(method='linear')
inter.plot()
plt.show()


#---------------------Variable IRRA---------------------
print("----------Variable IRRA------------")
#Hacemos la interpolación linear de la tendencia
IIRA_tend=np.array(descIRRA.trend)
indexesIIRA=np.isfinite(IIRA_tend)
coefs=np.polyfit(np.array(pd.to_datetime(descIRRA.trend.index).astype(int)/10**18)[indexesIIRA],IIRA_tend[indexesIIRA],1)
func=np.poly1d(coefs)


#Insertamos las columnas de tendencia y regresion al dataframe
serieIRRA.insert(1,'Tendencia',descIRRA.trend.interpolate(method="linear"))
serieIRRA.insert(2,'Regresion',func(np.array(pd.to_datetime(serieIRRA.index).astype(int)/10**18)))

plt.plot(serieIRRA.index, serieIRRA.Tendencia, serieIRRA.Regresion)
print(coefs)
plt.show()



#-----------------------------------------------------
#----------Cálculo de la correlación cruzada----------
# CREACION DE LOS DATAFRAMES

# importar CSV
serieTM = pd.read_csv('./TM_Santiago_limpio.csv', parse_dates = True)
serieP = pd.read_csv('./P_Santiago_limpio.csv', parse_dates = True)
serieIRRA = pd.read_csv('./IRRA_Santiago_limpio.csv', parse_dates = True)

# campo Fecha como índice
serieTM['Fecha'] = pd.to_datetime(serieTM['Fecha'])
serieTM = serieTM.set_index('Fecha')

serieP['Fecha'] = pd.to_datetime(serieP['Fecha'])
serieP = serieP.set_index('Fecha')

serieIRRA['Fecha'] = pd.to_datetime(serieIRRA['Fecha'])
serieIRRA = serieIRRA.set_index('Fecha')

# creamos dataframe conjunto
df_conjunto = serieTM
df_conjunto.inserT(0, 'P', serieP.P)
df_conjunto.insert(1, 'IRRA', serieIRRA.Irradiacion_global_diaria)

# ver dataframe
print(df_conjunto.head(4))
print(df_conjunto.tail(4))
print("\n")


# CORRELACIONES CRUZADAS
# índices sin NaN
indexes_TM_P = np.isfinite(df_conjunto.TM) & np.isfinite(df_conjunto.P)
indexes_TM_IRRA = np.isfinite(df_conjunto.TM) & np.isfinite(df_conjunto.IRRA)
indexes_P_IRRA = np.isfinite(df_conjunto.P) & np.isfinite(df_conjunto.IRRA)

# cálculo de correlaciones cruzadas
ccf_TM_P = sm.tsa.stattools.ccf(df_conjunto.TM[indexes_TM_P], df_conjunto.P[indexes_TM_P])
ccf_TM_IRRA = sm.tsa.stattools.ccf(df_conjunto.TM[indexes_TM_IRRA], df_conjunto.IRRA[indexes_TM_IRRA])
ccf_P_IRRA = sm.tsa.stattools.ccf(df_conjunto.P[indexes_TM_P], df_conjunto.IRRA[indexes_TM_P])

# graficamos la correlacion cruzada
plt.plot(ccf_TM_P)
plt.plot(ccf_TM_IRRA)
plt.plot(ccf_P_IRRA)

plt.show()



#-----------------------------------------------------
#---------Filtro en tendencia con media móvil---------
hash



#-----------------------------------------------------
#----------------------Predicción----------------------
